package com.example.todolistdemo;

import android.content.DialogInterface;

public interface onDialogCloseListener {
    void onDialogClose(DialogInterface dialogInterface);
}
